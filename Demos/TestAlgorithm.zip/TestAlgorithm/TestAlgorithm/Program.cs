﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestAlgorithm.Algorithms;
using System.Diagnostics;

namespace TestAlgorithm
{
    class Program
    {
        static void Main(string[] args)
        {
            var stopWatch = new Stopwatch();

            stopWatch.Start();
            var g = new Genetic(0, 9, FitnessFunc);
            var ind = g.Do();

            stopWatch.Stop();
            Console.WriteLine("Final, Value = {0}, Fitness = {1}", g.GetDecimalValue(ind.Chromosome), ind.Fitness);
            Console.WriteLine("Total Seconds = " + stopWatch.Elapsed.TotalSeconds);

            Console.ReadKey();
        }

        static double FitnessFunc(double x)
        {
            return x + 10 * Math.Sin(5 * x) + 7 * Math.Cos(4 * x);
        }
    }
}
