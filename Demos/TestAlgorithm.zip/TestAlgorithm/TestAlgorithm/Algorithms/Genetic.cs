﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestAlgorithm.Utils;

namespace TestAlgorithm.Algorithms
{
    public class Individual
    {
        public int Chromosome { get; set; }
        public double Fitness { get; set; }
    }

    public class Genetic
    {
        private int _populationSize = 1000;
        private int _chromosomeSize = 0;

        private int _loopCount = 120;
        private double _crossRate = 0.6;
        private double _mutateRate = 0.001;

        private int _miniNum = 0;
        private int _maxNum = 9;
        private int _precision = 4;

        private bool _elitism = true;

        private Func<double, double> _fitnessFunc = null;

        public Genetic(int miniNum, int maxNum, Func<double, double> fitnessFunc)
        {
            _miniNum = miniNum;
            _maxNum = maxNum;

            _fitnessFunc = fitnessFunc;
        }

        public double GetDecimalValue(int chromosome)
        {
            return chromosome / (Math.Pow(2, _chromosomeSize) - 1) * (_maxNum - _miniNum) + _miniNum;
        }

        public Individual Do()
        {
            Individual optimalIndividual = null;

            //Init.
            var population = GeneratePopulation();
            for (int i = 0; i < _loopCount; i++)
            {
                //Rank
                Sort(population);

                //Slection
                var selectedPopulation = Selection(population);

                //Crossover
                Crossover(selectedPopulation);

                //Mutation
                var curOptimalIndividual = Mutation(selectedPopulation);
                Console.WriteLine("Current {0}, Value = {1}, Fitness = {2}", i, GetDecimalValue(curOptimalIndividual.Chromosome), curOptimalIndividual.Fitness);

                if (optimalIndividual == null)
                    optimalIndividual = curOptimalIndividual;
                else
                {
                    if (DoubleUtil.GreaterThan(curOptimalIndividual.Fitness, optimalIndividual.Fitness))
                        optimalIndividual = curOptimalIndividual;
                }

                //
                population = selectedPopulation;
            }

            return optimalIndividual;
        }

        private List<Individual> GeneratePopulation()
        {
            var range = (int)((_maxNum - _miniNum) * Math.Pow(10, _precision));
            _chromosomeSize = Convert.ToString(range, 2).Length;

            var miniRand = 0;
            var maxRand = (int)(Math.Pow(2, _chromosomeSize));
            var population = new List<Individual>();

            var dic = new Dictionary<int, int>();
            while (dic.Count < _populationSize)
            {
                var rand = (new Random(Guid.NewGuid().GetHashCode())).Next(miniRand, maxRand);
                if (!dic.ContainsKey(rand))
                {
                    dic.Add(rand, 0);
                    population.Add(new Individual { Chromosome = rand, Fitness = Fitness(rand) });
                }
            }

            return population;
        }

        private void Sort(List<Individual> population)
        {
            //sort
            population.Sort((p1, p2) =>
            {
                if (DoubleUtil.GreaterThan(p1.Fitness, p2.Fitness))
                    return 1;
                else if (DoubleUtil.LessThan(p1.Fitness, p2.Fitness))
                    return -1;
                else
                    return 0;
            });
        }

        private List<Individual> Selection(List<Individual> population)
        {
            var fitnessSum = population.Sum(p => p.Fitness);
            var newPopulation = new List<Individual>();

            for (int i = 0; i < _populationSize; i++)
            {
                if (i == _populationSize - 1 && _elitism)
                {
                    var last = population.Last();
                    newPopulation.Add(new Individual { Chromosome = last.Chromosome, Fitness = last.Fitness });

                    break;
                }

                var selectedIndex = GetRouletteIndex(population, fitnessSum);
                var selectedIndividual = population[selectedIndex];

                newPopulation.Add(new Individual { Chromosome = selectedIndividual.Chromosome, Fitness = selectedIndividual.Fitness });
            }

            return newPopulation;
        }

        private void Crossover(List<Individual> population)
        {
            for (int i = 0; i < population.Count; i += 2)
            {
                if (i == population.Count - 1)
                    break;

                var rand = RandBetweenZeroAndOne();
                if (DoubleUtil.GreaterThan(rand, _crossRate))
                    continue;

                var crossPos = (int)(rand * _chromosomeSize);
                if (crossPos == 0 || crossPos == 1)
                    continue;

                var individual1 = population[i];
                var individual2 = population[i + 1];

                var chromosome1 = individual1.Chromosome;
                var chromosome2 = individual2.Chromosome;

                var leftLength = crossPos;
                var rightLength = _chromosomeSize - crossPos;

                individual1.Chromosome = ((chromosome1 >> rightLength) << rightLength) | ((chromosome2 << leftLength) >> leftLength);
                individual1.Fitness = Fitness(individual1.Chromosome);

                individual2.Chromosome = ((chromosome2 >> rightLength) << rightLength) | ((chromosome1 << leftLength) >> leftLength);
                individual2.Fitness = Fitness(individual2.Chromosome);
            }
        }

        private Individual Mutation(List<Individual> population)
        {

            Individual optimalIndividual = null;
            for (int i = 0; i < population.Count; i += 2)
            {
                var individual = population[i];

                var rand = RandBetweenZeroAndOne();
                if (DoubleUtil.LessThanOrClose(rand, _mutateRate))
                {
                    var mutatePos = (int)(rand * _chromosomeSize);
                    if (mutatePos == 0)
                        continue;

                    var chromosome = individual.Chromosome;

                    var bitStr = Convert.ToString(chromosome, 2).PadLeft(_chromosomeSize, '0');
                    var newc = 1 - int.Parse(bitStr[mutatePos].ToString());

                    individual.Chromosome = Convert.ToInt32(bitStr.Remove(mutatePos, 1).Insert(mutatePos, newc.ToString()), 2);
                    individual.Fitness = Fitness(individual.Chromosome);
                }

                if (optimalIndividual == null)
                    optimalIndividual = individual;
                else
                {
                    if (DoubleUtil.GreaterThan(individual.Fitness, optimalIndividual.Fitness))
                        optimalIndividual = individual;
                }
            }

            return optimalIndividual;
        } 

        private double Fitness(int chromosome)
        {
            if (_fitnessFunc == null)
                throw new InvalidOperationException();

            return _fitnessFunc(GetDecimalValue(chromosome));
        }

        private double GetFitnessSum(List<Individual> population, int index)
        {
            var sum = 0d;
            for (int i = 0; i <= index; i++)
            {
                sum += population[i].Fitness;
            }

            return sum;
        }

        private int GetRouletteIndex(List<Individual> population, double fitnessSum)
        {
            var rand = RandBetweenZeroAndOne() * fitnessSum;

            var first = 0;
            var last = _populationSize - 1;

            var mid = (last + first) / 2;
            var midFitnessSum = 0d;

            while (first < last)
            {
                midFitnessSum = GetFitnessSum(population, mid);

                if (DoubleUtil.GreaterThan(rand, midFitnessSum))
                    first = mid;
                else if (DoubleUtil.LessThan(rand, midFitnessSum))
                    last = mid;
                else
                    return mid;

                if (last - first == 1)
                    return last;

                mid = (last + first) / 2;
            }

            return last;
        }

        private double RandBetweenZeroAndOne()
        {
            int i = (new Random(Guid.NewGuid().GetHashCode())).Next(0, 100000);
            return (double)i / 100000;
        }
    }
}
